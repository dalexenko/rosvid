<?php

$zip = new ZipArchive;
if ($zip->open('roc01071.zip') === TRUE) {
    $zip->extractTo('D:\roc\roc01071');
    $zip->close();
    echo 'ok';
} else {
    echo 'failed';
}

copy('D:\\roc\\blank.dbf', 'D:\\roc\\sorted\\rov01071.dbf');
copy('D:\\roc\\blank.dbf', 'D:\\roc\\sorted\\rot01071.dbf');
copy('D:\\roc\\blank.dbf', 'D:\\roc\\sorted\\\rof01071.dbf');

$filename = "tl_terra.csv";
$str_arr=file ($filename);

if ($handle = opendir('D:\roc\roc01071')) 
{
    while (false !== ($file = readdir($handle))) 
	{
if ($file!=='.' and $file !=='..')
		{        

$fl_pieces = explode(".", $file);
		for ($i=0; $i<count($str_arr); $i++)
			{
			$pieces = explode(";", $str_arr[$i]);
			//echo $pieces[0]."---".substr($pieces[3], 0, 5)."\n";
			if ($fl_pieces[1]==$pieces[0])
					{
					//echo "$pieces[3]\n";
			//echo substr($file, 0, 3)."\n";
		
copy('D:\\roc\\blank.dbf', 'D:\\roc\\sorted\\'.$fl_pieces[0]."_".$fl_pieces[1].".dbf");			

if (substr($file, 0, 3)=='ROV')	
	{
	$command_ins = "cdbflite.exe D:\\roc\\sorted\\".$fl_pieces[0]."_".$fl_pieces[1].".dbf +D:\\roc\\roc01071\\".$file;
	system ($command_ins, $s);
	$command_upd = "cdbflite.exe D:\\roc\\sorted\\".$fl_pieces[0]."_".$fl_pieces[1].".dbf /field:KODBUDGET=".trim($pieces[3])." /update";
	system ($command_upd, $s);
	$command_join = "cdbflite.exe D:\\roc\\sorted\\rov01071.dbf +D:\\roc\\sorted\\".$fl_pieces[0]."_".$fl_pieces[1].".dbf";
	system ($command_join, $s);
	}
if (substr($file, 0, 3)=='ROT')	
	{
	$command_ins = "cdbflite.exe D:\\roc\\sorted\\".$fl_pieces[0]."_".$fl_pieces[1].".dbf +D:\\roc\\roc01071\\".$file;
	system ($command_ins, $s);
		$command_upd = "cdbflite.exe D:\\roc\\sorted\\".$fl_pieces[0]."_".$fl_pieces[1].".dbf /field:KODBUDGET=".trim($pieces[3])." /update";
	system ($command_upd, $s);
	$command_join = "cdbflite.exe D:\\roc\\sorted\\rot01071.dbf +D:\\roc\\sorted\\".$fl_pieces[0]."_".$fl_pieces[1].".dbf";
	system ($command_join, $s);
	}

if (substr($file, 0, 3)=='ROF')	
	{
	$command_ins = "cdbflite.exe D:\\roc\\sorted\\".$fl_pieces[0]."_".$fl_pieces[1].".dbf +D:\\roc\\roc01071\\".$file;
	system ($command_ins, $s);
		$command_upd = "cdbflite.exe D:\\roc\\sorted\\".$fl_pieces[0]."_".$fl_pieces[1].".dbf /field:KODBUDGET=".trim($pieces[3])." /update";
	system ($command_upd, $s);
	$command_join = "cdbflite.exe D:\\roc\\sorted\\rof01071.dbf +D:\\roc\\sorted\\".$fl_pieces[0]."_".$fl_pieces[1].".dbf";
	system ($command_join, $s);
	}	

unlink('D:\\roc\\sorted\\'.$fl_pieces[0]."_".$fl_pieces[1].".dbf");
	
					}
			}
		}
	}
    closedir($handle);
}

$arr_sokr_kekv = array(1110, 1120, 1132, 1133, 1160, 1171, 1172, 1340, 5000);

$db = dbase_open('D:\\roc\\sorted\\rov01071.dbf', 2);


if ($db_sqlite = sqlite_open('D:\\roc\\data\\rospis.sdb')) 
	{ 
    /*
	sqlite_query($db, 'CREATE TABLE rov01071 (KEKV numeric(4), KODBUDGET character (20), NAMEBUDGET character (150), MONTH numeric (2), SUMM numeric (16), S1 numeric (16), S2 numeric (16), S3 numeric (16), S4 numeric (16), S5 numeric (16), S6 numeric (16), S7 numeric (16), S8 numeric (16), S9 numeric (16), S10 numeric (16), S11 numeric (16), S12 numeric (16))');
	*/
    //sqlite_query($db, "INSERT INTO foo VALUES ('fnord')");
    //$result = sqlite_query($db, 'select bar from foo');
    //var_dump(sqlite_fetch_array($result)); 
	} 
	else 
		{
    echo "error!\n";
		}


if ($db) 
{

echo $record_numbers = dbase_numrecords($db);
  for ($i = 1; $i <= $record_numbers; $i++) 
	  {
      $row = dbase_get_record_with_names($db, $i);
	  unset($row['deleted']);

		if (in_array($row['KEKV'], $arr_sokr_kekv) != true)
		{
		if (substr($row['KEKV'], 0, -1)==111)
			{
			$row['KEKV']=1110;
			}
			elseif (substr($row['KEKV'], 0, -1)==116)
				{$row['KEKV']=1160;
			}
			else
			{
				$row['KEKV']=5000;
			}
		
		} 
			if ($row['MONTH']>0) 
			{
			$row['S'.$row['MONTH']]=$row['SUMM'];
			$row['SUMM']=0;
			}
			/*
			$rarr = array();
		
			foreach ($row as $n => $vl) { $rarr[] = $vl; }
			
			echo $i."\n";

			dbase_replace_record($db, $rarr, $i);
			*/

			$query = "insert into rov01071 (KEKV, KODBUDGET, MONTH, SUMM, S1, S2, S3, S4, S5, S6, S7, S8, S9, S10, S11, S12) values (".$row['KEKV'].", ".$row['KODBUDGET'].", ".$row['MONTH'].", ".$row['SUMM'].", ".$row['S1'].", ".$row['S2'].", ".$row['S3'].", ".$row['S4'].", ".$row['S5'].", ".$row['S6'].", ".$row['S7'].", ".$row['S8'].", ".$row['S9'].", ".$row['S10'].", ".$row['S11'].", ".$row['S12'].")";
			sqlite_query($db_sqlite, $query);
			echo $i."\n";

	  }
sqlite_close ($db_sqlite);
dbase_close($db);
}
?> 