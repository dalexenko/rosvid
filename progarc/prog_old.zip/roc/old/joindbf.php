<?
copy('D:\\roc\\blank.dbf', 'D:\\roc\\sorted\\rov01071.dbf');
copy('D:\\roc\\blank.dbf', 'D:\\roc\\sorted\\rot01071.dbf');
copy('D:\\roc\\blank.dbf', 'D:\\roc\\sorted\\\rof01071.dbf');

$filename = "tl_terra.csv";
$str_arr=file ($filename);

if ($handle = opendir('D:\roc\roc01071')) 
{
    while (false !== ($file = readdir($handle))) 
	{
if ($file!=='.' and $file !=='..')
		{        

$fl_pieces = explode(".", $file);
		for ($i=0; $i<count($str_arr); $i++)
			{
			$pieces = explode(";", $str_arr[$i]);
			//echo $pieces[0]."---".substr($pieces[3], 0, 5)."\n";
			if ($fl_pieces[1]==$pieces[0])
					{
					//echo "$pieces[3]\n";
			//echo substr($file, 0, 3)."\n";
		
copy('D:\\roc\\blank.dbf', 'D:\\roc\\sorted\\'.$fl_pieces[0]."_".$fl_pieces[1].".dbf");			

if (substr($file, 0, 3)=='ROV')	
	{
	$command_ins = "cdbflite.exe D:\\roc\\sorted\\".$fl_pieces[0]."_".$fl_pieces[1].".dbf +D:\\roc\\roc01071\\".$file;
	system ($command_ins, $s);
	//$command_upd = "cdbflite.exe D:\\roc\\sorted\\".$fl_pieces[0]."_".$fl_pieces[1].".dbf /field:KODBUDGET=".trim($pieces[3])." /update";
	//system ($command_upd, $s);
	$command_join = "cdbflite.exe D:\\roc\\sorted\\rov01071.dbf +D:\\roc\\sorted\\".$fl_pieces[0]."_".$fl_pieces[1].".dbf";
	system ($command_join, $s);
	}
if (substr($file, 0, 3)=='ROT')	
	{
	$command_ins = "cdbflite.exe D:\\roc\\sorted\\".$fl_pieces[0]."_".$fl_pieces[1].".dbf +D:\\roc\\roc01071\\".$file;
	system ($command_ins, $s);
	//$command_upd = "cdbflite.exe D:\\roc\\sorted\\".$fl_pieces[0]."_".$fl_pieces[1].".dbf /field:KODBUDGET=".trim($pieces[3])." /update";
	//system ($command_upd, $s);
	$command_join = "cdbflite.exe D:\\roc\\sorted\\rot01071.dbf +D:\\roc\\sorted\\".$fl_pieces[0]."_".$fl_pieces[1].".dbf";
	system ($command_join, $s);
	}

if (substr($file, 0, 3)=='ROF')	
	{
	$command_ins = "cdbflite.exe D:\\roc\\sorted\\".$fl_pieces[0]."_".$fl_pieces[1].".dbf +D:\\roc\\roc01071\\".$file;
	system ($command_ins, $s);
	//	$command_upd = "cdbflite.exe D:\\roc\\sorted\\".$fl_pieces[0]."_".$fl_pieces[1].".dbf /field:KODBUDGET=".trim($pieces[3])." /update";
	//system ($command_upd, $s);
	$command_join = "cdbflite.exe D:\\roc\\sorted\\rof01071.dbf +D:\\roc\\sorted\\".$fl_pieces[0]."_".$fl_pieces[1].".dbf";
	system ($command_join, $s);
	}	

unlink('D:\\roc\\sorted\\'.$fl_pieces[0]."_".$fl_pieces[1].".dbf");
	
					}
			}
		}
	}
    closedir($handle);
}
?>