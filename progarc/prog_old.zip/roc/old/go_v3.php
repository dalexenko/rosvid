<?php

// ����������� ���������� ����

$arr_sokr_kekv = array(1110, 1120, 1132, 1133, 1160, 1171, 1172, 1340, 5000);

// ���������� ������
/*
$zip = new ZipArchive;
if ($zip->open('roc01071.zip') === TRUE) {
    $zip->extractTo('D:\roc\roc01071');
    $zip->close();
    echo 'ok';
} else {
    echo 'failed';
}
*/
// ������ � ������ ������ ����������� ��������

if ($db_sqlite = sqlite_open('D:\\roc\\data\\rospis.sdb')) 
	{ 
    $result = sqlite_query($db_sqlite, 'select IDBUDGET, NAMETERR, KODBUDGET from budgets');
	$idbud_rows = sqlite_num_rows($result);   
	} 
	else 
	{
    echo "error!\n";
	}

// �������� ����� � �������������� ������� ������ dbf

if ($handle = opendir('D:\roc\roc01071')) 
	{
    while (false !== ($file = readdir($handle))) 
		{
		if ($file!=='.' and $file !=='..')
			{
			$fl_pieces = explode(".", $file);
			
			//echo $fl_pieces[1]."\n";

			$result = sqlite_query($db_sqlite, 'select * from budgets where IDBUDGET='.$fl_pieces[1]);
			$idbud_rows = sqlite_num_rows($result); 

			
			while ($entry = sqlite_fetch_array($result, SQLITE_ASSOC)) 
				{
				
				//echo $entry['IDBUDGET']."\n";
				
					if (substr($file, 0, 3)=='ROV')	
						{
						echo $file."\n";
						$db_dbf = dbase_open("D:\\roc\\roc01071\\".$file, 2);
						if ($db_dbf) 
						  {
						
							$record_numbers = dbase_numrecords($db_dbf);
							for ($i = 1; $i <= $record_numbers; $i++) 
								{
        						$row = dbase_get_record_with_names($db_dbf, $i); 
								
										if (in_array($row['KEKV'], $arr_sokr_kekv) != true)
								    {
								
								  	if (substr($row['KEKV'], 0, -1)==111)
										{
											$row['KEKV']=1110;
										}
									    elseif (substr($row['KEKV'], 0, -1)==116)
										{   
										$row['KEKV']=1160;
										}
										else
										{
										$row['KEKV']=5000;
										}
									
									}
									
									if ($row['MONTH']>0)
									{
									$sm='S'.$row['MONTH'];
									$s=$row['SUMM'];
									$row['SUMM']=0;
									$cols = "KEKV, KODBUDGET, MONTH, ".$sm;
									$values = $row['KEKV'].", ".$entry['KODBUDGET'].", ".$row['MONTH'].", ".$s;
									}
									else
										{
										$cols = "KEKV, KODBUDGET, MONTH, SUMM";
										$values = $row['KEKV'].", ".$entry['KODBUDGET'].", ".$row['MONTH'].", ".$row['SUMM'];
										}
								
						
					
								//}
								
								 $query = "insert into rov01071 (".$cols.") values (".$values.")";
								 //echo "\n";
								 sqlite_query($db_sqlite, $query);
								}
							
							}
							dbase_close($db_dbf);
						}
				 	}

			}     
		} 
  }      
	else 
	{
	echo "error!";
	}
closedir($handle);
sqlite_close ($db_sqlite);

?> 